npm i express --save 
npm i body-parser --save

npm i mongodb --save

npm i nodemon --save-dev 